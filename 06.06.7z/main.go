package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"
	"unicode"
)

const abc = "абвгдеежзийклмнопрстуфхцчшщыьэюя"

func main() {

	inputFile := os.Args[1]
	outputFile := os.Args[2]

	file, err := os.Open(inputFile)
	if err != nil {
		fmt.Println("Ошибка при открытии :", err)
		return
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)

	counter := make(map[rune]uint)
	n := 0
	for scanner.Scan() {
		n++
		for _, ch := range scanner.Text() {
			ch = unicode.ToLower(ch)

			if ch == 'ё' {
				ch = 'е'
			} else if ch == 'ъ' {
				ch = 'ь'
			}

			if strings.ContainsRune(abc, ch) {
				counter[ch]++
			}
		}
	}

	output, err := os.Create(outputFile)
	if err != nil {
		fmt.Println("Ошибка при создании :", err)
		return
	}
	defer output.Close()

	writer := bufio.NewWriter(output)

	for ch, count := range counter {
		line := fmt.Sprintf("%c %d\n", ch, count)
		_, err := writer.WriteString(line)
		if err != nil {
			fmt.Println("Ошибка при записи :", err)
			return
		}
	}

	err = writer.Flush()
	if err != nil {
		fmt.Println("Ошибка при сбросе :", err)
		return
	}

}
